<!-- Game Page -->

<?php
//Import the shared functions and output the head, heading, logo and navigation bar
include('common.php');

outputHeading('Home');
outputNavBar();
?>

<!--Placeholder Div for embedding game-->
<div id=gameholder>
        Game goes here
    </div>

<?php
//Output the footer and closing HTML tags
outputFooter();
?>